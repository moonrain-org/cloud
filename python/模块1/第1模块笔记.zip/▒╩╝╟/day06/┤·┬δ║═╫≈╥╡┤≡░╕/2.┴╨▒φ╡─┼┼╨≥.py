# num_list = [11, 22, 4, 5, 11, 99, 88]
# print(num_list)
# num_list.sort()  # 让num_list从小到大排序
# num_list.sort(reverse=True)  # # 让num_list从大到小排序
# print(num_list)

# user_list = ["王宝强", "Ab陈羽凡", "Alex", "贾乃亮", "贾乃", "1", 23]
# #       [29579, 23453, 24378]
# #       [65, 98, 38472, 32701, 20961]
# #       [65, 108, 101, 120]
# #       [49]
# print(user_list)
# """
# sort的排序原理
#     [ "x x x" ," x x x


