data = "1"

data_list = []
for char in data:
    v1 = ord(char)
    data_list.append(v1)

print(data)
print(data_list)