"""
。。。。
"""

name = "武沛齐"
age = 18
email = "xxx"
