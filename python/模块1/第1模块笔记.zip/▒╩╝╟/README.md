# Python全栈开发全新v2.0版本

> 本课程是由路飞学城打造，为大家提供优质的教学资源。

- 讲师：武沛齐 （微信：wupeiqi666）
- 示例代码和笔记下载：https://github.com/WuPeiqi/python_course
- 更多教学资源，关注B站 “凸头统治地球” -> https://space.bilibili.com/283478842

