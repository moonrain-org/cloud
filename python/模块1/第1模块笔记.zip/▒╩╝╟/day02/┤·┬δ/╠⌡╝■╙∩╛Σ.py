name = input("请输入用户名:")
if name == "alex":
    print("欢迎登陆")
else:
    print("失败")
