data = input(">>>")
print(data)  # "123123"
