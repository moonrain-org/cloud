print("看着风景美如画",end=",")
print("本想吟诗增天下",end=".")