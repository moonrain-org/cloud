print(50 * 10 / 5)
print(8 > 10)
print(30 % 2)
print(3 * "我爱我的祖国")
print("alex" == "wupeiqi")
print(666 == 666)
print("666" == 666)

print(int("100") * 3)  # 300
print(int("123") + int("88"))  # 201
print(str(111) + str(222))  # "111222"
print(str(111) * 3)  # "111111111"
print(int("8") > 7)  # True
print(str(111) == 111)  # False
print(bool(-1))  # True
print(bool(0))  # False
print(bool(""))  # False
print(bool("你好"))  # True
print(True == True)  # True
print(True == False)  # False
print(bool("") == bool(0))  # True
