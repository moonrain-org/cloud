print(1 > 2)
print(False)

print(1 == 1)
print(True)