# 1.使用print输出自己的姓名
# print("武沛齐")

# 2.换行输出
# print("春眠不觉晓，")
# print("出处闻啼鸟，")
# print("夜来风雨声，")
# print("花落知多少。")

# 3.一行输出
print("春眠不觉晓，", end="")
print("出处闻啼鸟，", end="")
print("夜来风雨声，", end="")
print("花落知多少。", end="")
