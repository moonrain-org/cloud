print("我是Alex我是Alex我是Alex我是Alex")

print("中国北京昌平区")

print("""中国北京昌平区
asdfasdf
asdfasdf
asdfasdf
asdfasfd
""")

print( "alex" + "是金角大王吧" )

print(3 * "我想吃饺子")