def = "alex"
as = 123

name = "alex"