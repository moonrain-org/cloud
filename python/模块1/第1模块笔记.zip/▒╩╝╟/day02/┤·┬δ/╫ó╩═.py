# 声明一个name变量
name = "alex"
age = 19 # 这表示当前用户的年龄