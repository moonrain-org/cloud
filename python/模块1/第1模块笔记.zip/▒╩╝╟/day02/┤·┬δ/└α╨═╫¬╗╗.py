print("6" + "9")

print(int("6") + int("9"))