# 1.计算二进制位长度
v1 = 5
v1.bit_length()

# 2.复数
v2 = 6 + 12j
print(v2.real)
print(v2.imag)
