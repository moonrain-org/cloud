# name = "生活不是电影，生活比电影苦"
#
# print(name[8:1:-1])  # 输出：活生，影电是不 【倒序】
# print(name[-1:1:-1])  # 输出：苦影电比活生，影电是不 【倒序】
#
# # 面试题：给你一个字符串，请将这个字符串翻转。
# value = name[-1::-1]
# print(value)  # 苦影电比活生，影电是不活生


message = "来做点py交易呀"
for char in message:
    print(char)