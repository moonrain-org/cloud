v1 = 0 or 4 and 3 or 7 or 9 and 6
print(v1)


v2 = 8 or 3 and 4 or 2 and 0 or 9 and 7
print(v2)


v3 = 0 or 2 and 3 and 4 or 6 and 0 or 3
print(v3)

v4 = not 8 or 3 and 4 or 2
print(v4)