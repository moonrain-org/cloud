# message = "%(name)s你什么时候过来呀？%(user)s今天不在呀。" % {"name": "死鬼", "user": "李杰"}
#
# print(message)


text = "%s，这个片我已经下载了90%%了，居然特么的断网了" %"兄弟"
print(text)