# action = "跑步"
# text = f"嫂子喜欢{action}，跑完之后满身大汗"
# print(text)

# text = f"嫂子的名字叫喵喵，今年{ 19 + 2 = }岁"
# print(text)
#
# v1 = f"嫂子今年{22}岁"
# print(v1)
#
# v2 = f"嫂子今年{22:#b}岁"
# print(v2)
#
# v3 = f"嫂子今年{22:#o}岁"
# print(v3)
#
# v4 = f"嫂子今年{22:#x}岁"
# print(v4)

name = "alex"
text = f"我是{ name.upper() }，我爱大铁锤"
print(text)